/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sortingalgorithmsgui;

import java.util.Random;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

/**
 *
 * @author ethan
 */
public class SortingTabs extends TabPane {

    private SortingTabs[] theTabs;
    private int nTabs;
    
    private TextArea tta1;
    private TextArea tta2;
    private TextArea tta3;
    private TextArea tta4;
    //here we created private variables for each of our text fields and areas
    // so we could call them within each tab
    //these first four represent our four title areas on our title page
    
    private TextField itf1;
    private TextField itf2;
    private TextField itf3;
    private TextField itf4;
    private TextField itf5;
    private TextField itf6;
    private TextField itf7;
    private TextField itf8;
    private TextField itf9;
    private TextField itf10;
    //These are our textfields for the insertion sort tab
    
    private TextField stf1;
    private TextField stf2;
    private TextField stf3;
    private TextField stf4;
    private TextField stf5;
    private TextField stf6;
    private TextField stf7;
    private TextField stf8;
    private TextField stf9;
    private TextField stf10;
    //These are our textfields for 
    
    private TextField qtf1;
    private TextField qtf2;
    private TextField qtf3;
    private TextField qtf4;
    private TextField qtf5;
    private TextField qtf6;
    private TextField qtf7;
    private TextField qtf8;
    private TextField qtf9;
    private TextField qtf10;

    private TextField btf1;
    private TextField btf2;
    private TextField btf3;
    private TextField btf4;
    private TextField btf5;
    private TextField btf6;
    private TextField btf7;
    private TextField btf8;
    private TextField btf9;
    private TextField btf10;
    
    private TextArea sta1;
    private TextArea sta2;
    private TextArea ita1;
    private TextArea ita2;
    private TextArea qta1;
    private TextArea qta2;
    private TextArea bta1;
    private TextArea bta2;
            

    public SortingTabs(int nTabs) {
        Tab title = new Tab();
        //this is where we created our tabs and their names
        getTabs().add(title);
        title.setText("Title");
        StackPane titlePane = new StackPane();
        //we created a pane for each tab to make it easier when adding our 
        //buttons and textfields
        title.setContent(titlePane);
        tta1 = new TextArea("Sorting Efficiency");
        tta2 = new TextArea("The two main criterias to judge which algorithm is better than the other have been");
        tta3 = new TextArea("1- Time taken to sort the given data");
        tta4 = new TextArea("2- Memory Space required to do so");
        tta1.setTranslateY(0);
        tta2.setTranslateY(20);
        tta3.setTranslateY(40);
        tta4.setTranslateY(60);
        titlePane.getChildren().addAll(tta1, tta2, tta3, tta4); //getChildren is a
        //method we use often to add our necessary buttons, textareas, and textfields
        //to our panes.
        //This is our title page and we added 4 text areas to display the
        //necessary information
        //We use setTranslate code a lot within our code and this is just to
        //relocate and move our textareas and textfields.
        Tab insSort = new Tab();
        getTabs().add(insSort);
        insSort.setText("Insertion Sort");
        StackPane insPane = new StackPane();
        insSort.setContent(insPane);
        //This is our tab for insertion sort
        Button insButt = new Button("Insertion Sort");
        insButt.setOnAction(this::processInsButtButtonPress);
        insButt.setTranslateY(40);
        insButt.setTranslateX(-80);
        //This is how we created buttons for our tabs
        //We create methods later in the code that we call here
        Button clear1 = new Button("Clear");
        clear1.setTranslateY(40);
        clear1.setOnAction(this::processClear1ButtonPress);
        //This is our clear button for our first sorting tab
        //We created multiple clear buttons for all 4 sorting tabs
        Button randomGen = new Button("Generate Random Numbers");
        randomGen.setTranslateY(40);
        randomGen.setTranslateX(120);
        randomGen.setOnAction(this::processRandomGenButtonPress);
        //This is our random generator button we declared
        ita1 = new TextArea("Insertion Sort Description:");
        ita2 = new TextArea("Insertion Sort is a sorting method which will create" +
        " two separate sections known as unsorted and sorted sections. Then through"
        + " shifting the numbers to the right we will sort the unsorted numbers"
        + " to their correct spot"); //This is our description we add to each
        //sorting tab which is just displayed text we created in a text area.
        ita1.setWrapText(true);
        ita2.setWrapText(true); // sets text wrap to true
        ita1.setMaxHeight(10); // we set a maximum height so the text area
        // doesnt take up the whole tab.
        ita2.setMaxHeight(30);
        ita1.setTranslateY(-250);
        ita2.setTranslateY(-190);
        
        itf1 = new TextField("5");
        itf2 = new TextField("2");
        itf3 = new TextField("9");
        itf4 = new TextField("7");
        itf5 = new TextField("10");
        itf6 = new TextField("1");
        itf7 = new TextField("3");
        itf8 = new TextField("7");
        itf9 = new TextField("0");
        itf10 = new TextField("6");
        //These are our textfield for insertion sort and they display example 
        //numbers for our code
        itf1.setMaxWidth(100);
        itf2.setMaxWidth(100);
        itf3.setMaxWidth(100);
        itf4.setMaxWidth(100);
        itf5.setMaxWidth(100);
        itf6.setMaxWidth(100);
        itf7.setMaxWidth(100);
        itf8.setMaxWidth(100);
        itf9.setMaxWidth(100);
        itf10.setMaxWidth(100);
        //Just setting a maximum size for our textfields which stays the same
        //throughout all the tabs.
        itf1.setTranslateX(-500);
        itf2.setTranslateX(-400);
        itf3.setTranslateX(-300);
        itf4.setTranslateX(-200);
        itf5.setTranslateX(-100);
        itf7.setTranslateX(100);
        itf8.setTranslateX(200);
        itf9.setTranslateX(300);
        itf10.setTranslateX(400);
        insPane.getChildren().addAll(insButt, itf1, itf2, itf3, itf4, itf5, itf6, itf7, itf8, itf9, itf10, clear1, randomGen, ita1, ita2);
        //adding all the buttons and fields to the pane
        Tab selectionSort = new Tab();
        getTabs().add(selectionSort);
        selectionSort.setText("Selection Sort");
        //Creates our next tab Selection Sort
        StackPane Selpane = new StackPane();
        selectionSort.setContent(Selpane);
        //Creates new pane for our selection sort tab
        Button selectionButt = new Button("Selection Sort");
        selectionButt.setOnAction(this::processSelectionButtButtonPress);
        //Our actual button for selection sort
        selectionButt.setTranslateY(40);
        selectionButt.setTranslateX(-80);

        Button clear = new Button("Clear");
        clear.setOnAction(this::processClearButtonPress);
        clear.setTranslateY(40);
        
        Button randomGen2 = new Button("Generate Random Numbers");
        randomGen2.setTranslateY(40);
        randomGen2.setTranslateX(120);
        randomGen2.setOnAction(this::processRandomGen2ButtonPress);
        
        sta1 = new TextArea("Selection Sort Description:");
        sta2 = new TextArea("Selection Sort is a sorting method which divides an array"
        + " into two subarrays classifed by sorted and unsorted elements. Then through" 
        + " a loop will keep swapping the minimum element in the array with the first " 
        + "element in the array.");
        //creates new text areas for our description on selection sort
        sta1.setWrapText(true);
        sta2.setWrapText(true); // sets text wrap to true
        sta1.setMaxHeight(10);
        sta2.setMaxHeight(30); //sets maximum height
        sta1.setTranslateY(-250);
        sta2.setTranslateY(-190);
        
        
        stf1 = new TextField("5");
        stf2 = new TextField("2");
        stf3 = new TextField("9");
        stf4 = new TextField("7");
        stf5 = new TextField("10");
        stf6 = new TextField("1");
        stf7 = new TextField("3");
        stf8 = new TextField("7");
        stf9 = new TextField("0");
        stf10 = new TextField("6");
        //Our new textfields for selection sort

        stf1.setMaxWidth(100);
        stf2.setMaxWidth(100);
        stf3.setMaxWidth(100);
        stf4.setMaxWidth(100);
        stf5.setMaxWidth(100);
        stf6.setMaxWidth(100);
        stf7.setMaxWidth(100);
        stf8.setMaxWidth(100);
        stf9.setMaxWidth(100);
        stf10.setMaxWidth(100);

        stf1.setTranslateX(-500);
        stf2.setTranslateX(-400);
        stf3.setTranslateX(-300);
        stf4.setTranslateX(-200);
        stf5.setTranslateX(-100);
        stf7.setTranslateX(100);
        stf8.setTranslateX(200);
        stf9.setTranslateX(300);
        stf10.setTranslateX(400);
        Selpane.getChildren().addAll(selectionButt, stf1, stf2, stf3, stf4, stf5, stf6, stf7, stf8, stf9, stf10, clear, randomGen2, sta1, sta2);
        // Adds all our buttons and text fields to our selection sort tab
        Tab quickSort = new Tab();
        getTabs().add(quickSort);
        quickSort.setText("Quick Sort");
        //Creates a new tab for Quick Sort
        StackPane quickPane = new StackPane();
        quickSort.setContent(quickPane);
        //Creates a new pane for Quick Sort
        Button quickButt = new Button("Quick Sort");
        quickButt.setTranslateY(40);
        quickButt.setTranslateX(-80);
        quickButt.setOnAction(this::processQuickButtButtonPress);
        quickSort.setContent(quickPane);
        //Creates our Quick Sort button
        Button clear2 = new Button("Clear");
        clear2.setTranslateY(40);
        clear2.setOnAction(this::processClear2ButtonPress);

        Button randomGen3 = new Button("Generate Random Numbers");
        randomGen3.setTranslateY(40);
        randomGen3.setTranslateX(120);
        randomGen3.setOnAction(this::processRandomGen3ButtonPress);
        
        qta1 = new TextArea("Quick Sort Description:");
        qta2 = new TextArea("Quick Sort is a sorting method which designates a 'pivot'"
        + " and seperates an array into two subarrays with values less than and greater"
        + " than that pivot. It will then sort the array accordingly.");
        //creates text areas for our description for quick sort tab
        qta1.setWrapText(true);
        qta2.setWrapText(true); // sets text wrap to true
        qta1.setMaxHeight(10); // sets a max height for the text areas
        qta2.setMaxHeight(30);
        qta1.setTranslateY(-250);
        qta2.setTranslateY(-190);
        
        qtf1 = new TextField("5");
        qtf2 = new TextField("2");
        qtf3 = new TextField("9");
        qtf4 = new TextField("7");
        qtf5 = new TextField("10");
        qtf6 = new TextField("1");
        qtf7 = new TextField("3");
        qtf8 = new TextField("7");
        qtf9 = new TextField("0");
        qtf10 = new TextField("6");
        //Creates textfields for QuickSort
        qtf1.setMaxWidth(100);
        qtf2.setMaxWidth(100);
        qtf3.setMaxWidth(100);
        qtf4.setMaxWidth(100);
        qtf5.setMaxWidth(100);
        qtf6.setMaxWidth(100);
        qtf7.setMaxWidth(100);
        qtf8.setMaxWidth(100);
        qtf9.setMaxWidth(100);
        qtf10.setMaxWidth(100);

        qtf1.setTranslateX(-500);
        qtf2.setTranslateX(-400);
        qtf3.setTranslateX(-300);
        qtf4.setTranslateX(-200);
        qtf5.setTranslateX(-100);
        qtf7.setTranslateX(100);
        qtf8.setTranslateX(200);
        qtf9.setTranslateX(300);
        qtf10.setTranslateX(400);
        quickPane.getChildren().addAll(quickButt, qtf1, qtf2, qtf3, qtf4, qtf5, qtf6, qtf7, qtf8, qtf9, qtf10, clear2, randomGen3, qta1, qta2);
        //Adds all of our buttons and textfields to our Quick Sort tab
        Tab bubbleSort = new Tab();
        getTabs().add(bubbleSort);
        bubbleSort.setText("Bubble Sort");
        //Creates a new tab named Bubble Sort
        StackPane bubPane = new StackPane();
        bubbleSort.setContent(bubPane);
        //Creates a new pane for our Bubble Sort tab
        Button bubbleButt = new Button("Bubble Sort");
        bubbleButt.setTranslateY(40);
        bubbleButt.setTranslateX(-80);
        bubbleButt.setOnAction(this::processbubbleButtButtonPress);
        //Creates our Bubble Sort button
        Button clear3 = new Button("Clear");
        clear3.setTranslateY(40);
        clear3.setOnAction(this::processClear3ButtonPress);
        
        bta1 = new TextArea("Bubble Sort Description:");
        bta2 = new TextArea("Bubble Sort is a sorting method that is fairly simple" +
        " which will loop through a cycle of swapping the adjacent elements if they"
        + " are in the wrong order.");
        //Creates our text areas for our description for our Bubble Sort tab
        bta1.setWrapText(true);
        bta2.setWrapText(true); // sets text wrap to true
        bta1.setMaxHeight(10);
        bta2.setMaxHeight(30);  // sets a maximum height
        bta1.setTranslateY(-250);
        bta2.setTranslateY(-190);
        
        Button randomGen4 = new Button("Generate Random Numbers");
        randomGen4.setTranslateY(40);
        randomGen4.setTranslateX(120);
        randomGen4.setOnAction(this::processRandomGen4ButtonPress);
        
        btf1 = new TextField("5");
        btf2 = new TextField("2");
        btf3 = new TextField("9");
        btf4 = new TextField("7");
        btf5 = new TextField("10");
        btf6 = new TextField("1");
        btf7 = new TextField("3");
        btf8 = new TextField("7");
        btf9 = new TextField("0");
        btf10 = new TextField("6");
        //Creates our textfields for bubble sort
        btf1.setMaxWidth(100);
        btf2.setMaxWidth(100);
        btf3.setMaxWidth(100);
        btf4.setMaxWidth(100);
        btf5.setMaxWidth(100);
        btf6.setMaxWidth(100);
        btf7.setMaxWidth(100);
        btf8.setMaxWidth(100);
        btf9.setMaxWidth(100);
        btf10.setMaxWidth(100);

        btf1.setTranslateX(-500);
        btf2.setTranslateX(-400);
        btf3.setTranslateX(-300);
        btf4.setTranslateX(-200);
        btf5.setTranslateX(-100);

        btf7.setTranslateX(100);
        btf8.setTranslateX(200);
        btf9.setTranslateX(300);
        btf10.setTranslateX(400);
        bubPane.getChildren().addAll(bubbleButt, btf1, btf2, btf3, btf4, btf5, btf6, btf7, btf8, btf9, btf10, clear3, randomGen4, bta1, bta2);

    }

    public void processClearButtonPress(ActionEvent evt) {
        stf1.setText("");
        stf2.setText("");
        stf3.setText("");
        stf4.setText("");
        stf5.setText("");
        stf6.setText("");
        stf7.setText("");
        stf8.setText("");
        stf9.setText("");
        stf10.setText("");
        //Our method for clear button is called above and these events occur
        // as soon as the button is pressed. It is a simple method as all it does
        // is set the text of all the user input textfields to display nothing. 
        // Since we created multiple clear buttons for each tab, they will just 
        // repeat the same code.
    }

    public void processClear1ButtonPress(ActionEvent evt) {
        itf1.setText("");
        itf2.setText("");
        itf3.setText("");
        itf4.setText("");
        itf5.setText("");
        itf6.setText("");
        itf7.setText("");
        itf8.setText("");
        itf9.setText("");
        itf10.setText("");
    }

    public void processClear2ButtonPress(ActionEvent evt) {
        qtf1.setText("");
        qtf2.setText("");
        qtf3.setText("");
        qtf4.setText("");
        qtf5.setText("");
        qtf6.setText("");
        qtf7.setText("");
        qtf8.setText("");
        qtf9.setText("");
        qtf10.setText("");
    }

    public void processClear3ButtonPress(ActionEvent evt) {
        btf1.setText("");
        btf2.setText("");
        btf3.setText("");
        btf4.setText("");
        btf5.setText("");
        btf6.setText("");
        btf7.setText("");
        btf8.setText("");
        btf9.setText("");
        btf10.setText("");
    }
    
    public void processRandomGenButtonPress(ActionEvent evt) {
        Random rand = new Random();
        itf1.setText(rand.nextInt(10) + "");
        itf2.setText(rand.nextInt(10) + "");
        itf3.setText(rand.nextInt(10) + "");
        itf4.setText(rand.nextInt(10) + "");
        itf5.setText(rand.nextInt(10) + "");
        itf6.setText(rand.nextInt(10) + "");
        itf7.setText(rand.nextInt(10) + "");
        itf8.setText(rand.nextInt(10) + "");
        itf9.setText(rand.nextInt(10) + "");
        itf10.setText(rand.nextInt(10) + "");
        //This is our method for our random number generator button and as you 
        // can see it sets the text of each userinput textfield to a random number
        // from 0 to 10. We didn't know what maximum to have so we have yet 
        // to set that value. Again,  we created multiple buttons for each
        // tab.
    }
    
    public void processRandomGen2ButtonPress(ActionEvent evt) {
        Random rand = new Random();
        stf1.setText(rand.nextInt(10) + "");
        stf2.setText(rand.nextInt(10) + "");
        stf3.setText(rand.nextInt(10) + "");
        stf4.setText(rand.nextInt(10) + "");
        stf5.setText(rand.nextInt(10) + "");
        stf6.setText(rand.nextInt(10) + "");
        stf7.setText(rand.nextInt(10) + "");
        stf8.setText(rand.nextInt(10) + "");
        stf9.setText(rand.nextInt(10) + "");
        stf10.setText(rand.nextInt(10) + "");
    }
    
    public void processRandomGen3ButtonPress(ActionEvent evt) {
        Random rand = new Random();
        qtf1.setText(rand.nextInt(10) + "");
        qtf2.setText(rand.nextInt(10) + "");
        qtf3.setText(rand.nextInt(10) + "");
        qtf4.setText(rand.nextInt(10) + "");
        qtf5.setText(rand.nextInt(10) + "");
        qtf6.setText(rand.nextInt(10) + "");
        qtf7.setText(rand.nextInt(10) + "");
        qtf8.setText(rand.nextInt(10) + "");
        qtf9.setText(rand.nextInt(10) + "");
        qtf10.setText(rand.nextInt(10) + "");
    }
    
    public void processRandomGen4ButtonPress(ActionEvent evt) {
        Random rand = new Random();
        btf1.setText(rand.nextInt(10) + "");
        btf2.setText(rand.nextInt(10) + "");
        btf3.setText(rand.nextInt(10) + "");
        btf4.setText(rand.nextInt(10) + "");
        btf5.setText(rand.nextInt(10) + "");
        btf6.setText(rand.nextInt(10) + "");
        btf7.setText(rand.nextInt(10) + "");
        btf8.setText(rand.nextInt(10) + "");
        btf9.setText(rand.nextInt(10) + "");
        btf10.setText(rand.nextInt(10) + "");
    }

    public static int getIntFromTextField(TextField textField) {
        String text = textField.getText();
        return Integer.parseInt(text);
        //This code helps us convert text from our userinput textfields to 
        // int values we are able to use in our sorting methods.
    }

    public void processInsButtButtonPress(ActionEvent evt){
        int[] x = new int[10];
        x[0] = getIntFromTextField(itf1);
        x[1] = getIntFromTextField(itf2);
        x[2] = getIntFromTextField(itf3);
        x[3] = getIntFromTextField(itf4);
        x[4] = getIntFromTextField(itf5);
        x[5] = getIntFromTextField(itf6);
        x[6] = getIntFromTextField(itf7);
        x[7] = getIntFromTextField(itf8);
        x[8] = getIntFromTextField(itf9);
        x[9] = getIntFromTextField(itf10);
        int[] a = insertionSort(x, 0, x.length);
        //This is our method for insertion sort button and 
        // we create an array with 10 values while converting
        // each text value into an int value. 
        // We repeat this process for each sorting tab
        itf1.setText(x[0] + "");
        itf2.setText(x[1] + "");
        itf3.setText(x[2] + "");
        itf4.setText(x[3] + "");
        itf5.setText(x[4] + "");
        itf6.setText(x[5] + "");
        itf7.setText(x[6] + "");
        itf8.setText(x[7] + "");
        itf9.setText(x[8] + "");
        itf10.setText(x[9] + "");
    }
    public void processSelectionButtButtonPress(ActionEvent evt) {

        int[] x = new int[10];
        x[0] = getIntFromTextField(stf1);
        x[1] = getIntFromTextField(stf2);
        x[2] = getIntFromTextField(stf3);
        x[3] = getIntFromTextField(stf4);
        x[4] = getIntFromTextField(stf5);
        x[5] = getIntFromTextField(stf6);
        x[6] = getIntFromTextField(stf7);
        x[7] = getIntFromTextField(stf8);
        x[8] = getIntFromTextField(stf9);
        x[9] = getIntFromTextField(stf10);
        int[] a = selectionSort(x, 0, x.length);
        
        stf1.setText(x[0] + "");
        stf2.setText(x[1] + "");
        stf3.setText(x[2] + "");
        stf4.setText(x[3] + "");
        stf5.setText(x[4] + "");
        stf6.setText(x[5] + "");
        stf7.setText(x[6] + "");
        stf8.setText(x[7] + "");
        stf9.setText(x[8] + "");
        stf10.setText(x[9] + "");
    }
    public void processQuickButtButtonPress(ActionEvent evt) {

        int[] x = new int[10];
        x[0] = getIntFromTextField(qtf1);
        x[1] = getIntFromTextField(qtf2);
        x[2] = getIntFromTextField(qtf3);
        x[3] = getIntFromTextField(qtf4);
        x[4] = getIntFromTextField(qtf5);
        x[5] = getIntFromTextField(qtf6);
        x[6] = getIntFromTextField(qtf7);
        x[7] = getIntFromTextField(qtf8);
        x[8] = getIntFromTextField(qtf9);
        x[9] = getIntFromTextField(qtf10);
        int[] a = quickSort(x, 0, x.length);
        
        qtf1.setText(x[0] + "");
        qtf2.setText(x[1] + "");
        qtf3.setText(x[2] + "");
        qtf4.setText(x[3] + "");
        qtf5.setText(x[4] + "");
        qtf6.setText(x[5] + "");
        qtf7.setText(x[6] + "");
        qtf8.setText(x[7] + "");
        qtf9.setText(x[8] + "");
        qtf10.setText(x[9] + "");
    }
    
    public void processbubbleButtButtonPress(ActionEvent evt) {

        int[] x = new int[10];
        x[0] = getIntFromTextField(btf1);
        x[1] = getIntFromTextField(btf2);
        x[2] = getIntFromTextField(btf3);
        x[3] = getIntFromTextField(btf4);
        x[4] = getIntFromTextField(btf5);
        x[5] = getIntFromTextField(btf6);
        x[6] = getIntFromTextField(btf7);
        x[7] = getIntFromTextField(btf8);
        x[8] = getIntFromTextField(btf9);
        x[9] = getIntFromTextField(btf10);
        int[] a = bubbleSort(x);
        
        btf1.setText(x[0] + "");
        btf2.setText(x[1] + "");
        btf3.setText(x[2] + "");
        btf4.setText(x[3] + "");
        btf5.setText(x[4] + "");
        btf6.setText(x[5] + "");
        btf7.setText(x[6] + "");
        btf8.setText(x[7] + "");
        btf9.setText(x[8] + "");
        btf10.setText(x[9] + "");
    }
    
    public static int[] quickSort(int[] a, int first, int last){
        //only do quicksort for more than 3 array elements
        if(last - first > 3){
            //calculate mid element
            int mid = first + (last - first) / 2;
            //sort first, middle, and last elements
            if(a[first] > a[mid]){
                swap2Elements(a, first, mid);
            }
            if(a[mid] > a[last - 1]){
                swap2Elements(a, mid, last - 1);
            }
            if(a[first] > a[mid]){
                swap2Elements(a, first, mid);
            }
            //move pivot to the end
            swap2Elements(a, mid, last - 1);
            int pivot = a[last - 1];
            
            //start from both sides and work inwards
            int indexFromLeft = first + 1;
            int indexFromRight = last - 2;
            boolean done = false; //this becomes true once all elements are positioned correctly relative to pivot
            
            while(!done){
                //move from left until we find an element greater than the pivot
                while(a[indexFromLeft] < pivot){
                    indexFromLeft++;
                }
                //now move from right until we find element less than pivot
                while(a[indexFromRight] > pivot){
                    indexFromRight--;
                }
                //provided that the left and right pointer have not crossed, swap those elements
                if(indexFromLeft < indexFromRight){
                    swap2Elements(a, indexFromLeft, indexFromRight);
                    indexFromLeft++;
                    indexFromRight--;
                }
                else{
                    done = true;
                }
            }
            //once the pointers cross, move the pivot to the correct location
            swap2Elements(a, last - 1, indexFromLeft);
            //lets use quicksort to sort each subarray on either side of the pivot
            quickSort(a, first, indexFromLeft);
            quickSort(a, indexFromLeft, last);
            
        }
        else{
            selectionSort(a, first, last);
        }
        return a;
    }//We took the method from the code we worked on in class for Quick Sort
    // and changed it to an array constructor with a return value. 
    // This return value allows us to successfully convert text to int and use 
    // this method within our code. //We do a similar process with each sorting
    // method
    
    
    
    public static int[] selectionSort(int[] a, int first, int last) {
        // sort a between indices first and last
        for (int i = first; i < last; i++) {
            //initialize with the first element in the unsorted array
            int small = a[i];
            int iSmall = i;
            // now look for the smallest element
            for (int j = i + 1; j < last; j++) {
                if (a[j] < small) {
                    small = a[j];
                    iSmall = j;
                }
            }

            //we now know the smallest value in the unsorted array
            if (i != iSmall) {
                swap2Elements(a, i, iSmall);
            }

        }
        return a;

    }
    
    public static int[] insertionSort(int[] a, int first, int last){
        for (int i = first + 1; i < last; i++){
            //store value that well insert
            int next = a[i];
            //start searching backwards for where we insert next
            int iFill = i -1;
            while((iFill >= 0) && next < a[iFill]){
                a[iFill + 1] = a[iFill];
                iFill--;
            }
            //when were done, we know where the element belongs
            a[iFill + 1] = next;
            
        }
        return a;
    }
    
    public static int[] bubbleSort(int bub[])
    {
        int n = bub.length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (bub[j] > bub[j+1])
                {
                    // swap temp and arr[i]
                    int temp = bub[j];
                    bub[j] = bub[j+1];
                    bub[j+1] = temp;
                }
        return bub;
        //This code for bubble sort is fairly simple as all we have to do
        // is swap arrays between our temporary array and our initial array.
    }

    public static void swap2Elements(int[] a, int i, int j) {
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
        //This is the swap2Elements code we used in class that we call in most
        // of our methods.
    }
}
