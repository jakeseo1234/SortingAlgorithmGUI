/*
 * hi
 * 
 */
package com.mycompany.sortingalgorithmsgui;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class SortingButton extends Tab{
    private Pane sortPane;
    private Button sortNumbers;
    
    private Text text;
    
    
public SortingButton(Pane sortPane, String string){
    super(string);
        this.sortPane = sortPane;
        // Step 2
        sortNumbers = new Button("Sort Numbers");
        
        BorderPane shapeBox = new BorderPane();
        shapeBox.setCenter(this.sortPane);
        shapeBox.setTop(sortNumbers);
        setContent(shapeBox);
        
        // Step 5
        sortNumbers.setOnAction(this::processButtonPress);
        // The :: means the processButtonPress method in this object
        //We created a seperate method for sorting button to call it on all 4 of
        // our tabs. 
   }
    // Step 4
    public void processButtonPress(ActionEvent evt) {
    }
    
    
    
}
    
    
    
    

