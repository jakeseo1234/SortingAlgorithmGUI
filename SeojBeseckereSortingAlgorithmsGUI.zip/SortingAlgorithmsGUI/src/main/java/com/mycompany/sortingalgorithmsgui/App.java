package com.mycompany.sortingalgorithmsgui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class App extends Application {

    @Override
    public void start(Stage stage) {
        SortingTabs SortMethods = new SortingTabs(4);
        Scene scene = new Scene(SortMethods, 640, 480);
        stage.setScene(scene);
        stage.show();
        //This creates our four tabs needed for sorting
        // we declared a new scene and used corresponding code to visualize it
    }

    public static void main(String[] args) {
        launch();
    }

}